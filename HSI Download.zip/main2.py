import pandas as pd
import yfinance as yf

tickerlist = ['^HSI', '000001.SS','399001.SZ','^DJI','^IXIC','^GSPC','^VIX','^N225']
tickername = ['HSI', 'SS', 'SZ', 'DJI','IXIC', 'GSPC' ,'VIX', 'N225']
t_len = len(tickerlist)

df_all = pd.DataFrame()

df = yf.Ticker(tickerlist[0]).history(period="3y").reset_index()
df = df[df['Date']>= '2019-01-01']
df['M0'] = df['Date'].dt.strftime('%Y%m')
df = df['M0'].unique()

df_all = pd.DataFrame(df, columns=['M0'])

for i in range(t_len):
    tindex = tickerlist[i]
    tname = tickername[i]
    df = yf.Ticker(tindex).history(period="3y").reset_index()
    df = df[df['Date']>= '2019-01-01']
    df['M0'] = df['Date'].dt.strftime('%Y%m')

    df_rng = df['Close'].groupby(by=df['M0']).agg(['min','max']).reset_index()
    df_rng[tname +'_Range']=df_rng['max']-df_rng['min']

    df_chg=df['Date'].groupby(by=df['M0']).agg(['min','max']).reset_index()
    df_chg = df_chg.merge(df[['Date','Close']], left_on='min', right_on='Date').rename(columns={"Date": "minDate", "Close": "startClose"})
    df_chg = df_chg.merge(df[['Date','Close']], left_on='max', right_on='Date').rename(columns={"Date": "maxDate", "Close": "endClose"})
    df_chg[tname+'_Change'] = (df_chg['endClose'] - df_chg['startClose']) / df_chg['startClose']

    df_vol = df['Volume'].groupby(by=df['M0']).agg(['sum']).reset_index().rename(columns={"sum": tname+"_vol"})
    df_vol[tname+"_vol_p1"] = df_vol[tname+"_vol"].shift(1)
    df_vol[tname+"_volchg"] = (df_vol[tname+"_vol"] - df_vol[tname+"_vol_p1"]) / df_vol[tname+"_vol_p1"]


    df = df_chg.merge(df_rng, left_on='M0', right_on='M0').merge(df_vol, left_on='M0', right_on='M0')[['M0',tname+'_Change',tname+'_Range', tname+'_volchg',]]
    df_all = df_all.merge(df, left_on='M0', right_on='M0')

df_all.to_csv('hsi.csv',index=False)