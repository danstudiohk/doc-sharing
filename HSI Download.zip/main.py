import pandas as pd
import yfinance as yf



tickerlist = ['^HSI', '^HSIL']
tickername = ['HSI', 'HSIL']
t_len = len(tickerlist)

for i in range(t_len):
	tickerindex = tickerlist[i]
	tickername = tickername[i]
	df = yf.Ticker(tickerindex).history(period="3y").reset_index()
	df = df[df['Date']>= '2019-01-01']
	df['M0'] = df['Date'].dt.strftime('%Y%m')

	df_rng = df['Close'].groupby(by=df['M0']).agg(['min','max']).reset_index()
	df_rng[tickername[i]+'_Range'] = df_rng['max'] - df_rng['min']

df_chg = df['Date'].groupby(by=df['M0']).agg(['min','max']).reset_index()
df_chg = df_chg.merge(df[['Date','Close']], left_on='min', right_on='Date').rename(columns={"Date": "minDate", "Close": "startlose"})
df_chg = df_chg.merge(df[['Date','Close']], left_on='max', right_on='Date').rename(columns={"Date": "maxDate", "Close": "endClose"})
df_chg[tickername[i]+'_Change'] = (df_chg['endClose'] - df_chg['startlose']) / df_chg['startlose']


df = df_chg.merge(df_rng, left_on='M0', right_on='M0')
print(df)

#[['M0','HSI_Change','HSI_Range']]
#df.to_csv('hsi.csv',index=False)


